#!/bin/bash

echo "========================================"
echo "   Notrix Investment Fund"
echo "   Financial Command Center"
echo "========================================"
echo ""

# Get the directory where the script is located
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
cd "$SCRIPT_DIR"

# Check if venv exists, if not create it
if [ ! -d "venv" ]; then
    echo "Creating virtual environment..."
    python3 -m venv venv
fi

# Activate virtual environment
source venv/bin/activate 2>/dev/null || source venv/Scripts/activate 2>/dev/null

# Install requirements
echo "Installing/updating dependencies..."
pip install -r requirements.txt -q

# Download TextBlob corpora if needed
python -m textblob.download_corpora lite 2>/dev/null

echo ""
echo "========================================"
echo "  TIP: For live market data, get a FREE"
echo "  API key from finnhub.io and enter it"
echo "  in the sidebar, or set it below:"
echo "========================================"
echo ""

# Uncomment and set your API keys here:
# export FINNHUB_API_KEY="your_finnhub_key_here"
# export TWELVE_DATA_API_KEY="your_twelve_data_key_here"
# export ALPHA_VANTAGE_API_KEY="your_alpha_vantage_key_here"
# export FMP_API_KEY="your_fmp_key_here"

echo "Starting Notrix Financial Command Center..."
echo "App will open at: http://localhost:8501"
echo ""

# Run the app
streamlit run app.py
